// Generic Connection Tests
require('./connection');

// Stanza Support Tests
require('./stanza-dataforms');
